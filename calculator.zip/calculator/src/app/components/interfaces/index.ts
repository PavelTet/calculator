export interface ItemList {
  name: string;
  type: string;
  trials: number;
  date: string;
  report: boolean;
  status?: string;
}
