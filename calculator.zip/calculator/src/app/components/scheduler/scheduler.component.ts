import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ItemList } from '../interfaces';

@Component({
  selector: 'app-scheduler',
  templateUrl: './scheduler.component.html',
  styleUrls: ['./scheduler.component.scss']
})
export class SchedulerComponent implements OnInit {

  public form: FormGroup;
  public status = ['Pending', 'Running', 'Success', 'Failure'];
  public list: ItemList[] = [];
  public tableList: ItemList[] = [];

  constructor(private fb: FormBuilder) {
  }

  ngOnInit(): void {
    this.form = this.fb.group({
      name: ['', [Validators.required, Validators.maxLength(5)]],
      type: ['basic', []],
      date: ['', [Validators.required]],
      trial: ['', [Validators.required]],
      report: [false, [Validators.required]],
    });
  }

  submitForm(): void {
    if (this.form.valid) {
      const data = this.form.getRawValue();
      this.addItemToList(data);
    }
  }

  onSearch(event): void {
    const value = event.target.value;
    this.tableList = this.list.filter((item) => item.name.includes(value) || item.type.includes(value));
  }

  addItemToList(item: ItemList): void {
    this.list.push({...item, status: this.status[this.getRandomNum()]});
    this.tableList = this.list;
  }

  private getRandomNum(): number {
    const min = 0;
    const max = 3;
    return Math.floor(Math.random() * (max - min + 1) + min);
  }


}
